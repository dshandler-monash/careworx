import ResNav from "../ResNav/resNav";
import SearchPage from "../SearchPage/SearchPage";

const Third = () =>{
    return (
        <div>
            <ResNav></ResNav>
            <SearchPage></SearchPage>
        </div>
    )
};

export default Third;