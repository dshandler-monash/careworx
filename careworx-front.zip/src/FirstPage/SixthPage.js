import NavigationBar from "../navigationBar/NavigationBar";
// import RollPic from "../rollPic/rollPic";
import TopAnchor from "../topAnchor/TopAnchor";
import FindHome from "../FindHome/FindHome";
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import ResNav from "../ResNav/resNav";


const Sixth = () =>{
    return (
        <div>
            <ResNav></ResNav>
        </div>
    )
};

export default Sixth;